The content of each file <TABLE>.sql in this folder will be inserted
at top of the deletion-script if at least one row of <TABLE> is deleted.
