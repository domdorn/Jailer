analyse ${JAILER_ENTITY};
analyse ${JAILER_GRAPH};
analyse ${JAILER_DEPENDENCY};
analyse ${JAILER_SET};
