update statistics ${JAILER_ENTITY};
update statistics ${JAILER_GRAPH};
update statistics ${JAILER_DEPENDENCY};
update statistics ${JAILER_SET};
